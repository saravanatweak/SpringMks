package springAnno.service;

import java.util.List;

import springAnno.model.Customer;

public interface CustomerService {

	List<Customer> findAll();

}
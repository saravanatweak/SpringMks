package springAnno.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import springAnno.model.Customer;
import springAnno.repository.CustomerRepository;

//service All the time business logic will be here only
@Service("customerServiceUsingAnno")
public class CustomerServiceImpl implements CustomerService {

//hardcoded referecen to repository // By using spring we can eliminate this kind of configuration
//private CustomerRepository customerRepository = new HibernateCustomerRepositoryImpl();
	
	//@Autowired
	private CustomerRepository customerRepository;
	//Because it was annotated with @autowired it will automatically inject repository bean (which was annotated with @repository in repository impl class) to here.
	//There was no wiring code, if you look at applicationContext.xml , you'll see there's just the scanner and the annotation config marcation, and we're good. 

	//Before using setter level autowiring comment at memeber level autowiring annotation 
	//@Autowired
	public void setCustomerRepository(CustomerRepository customerRepository) {
		System.out.println("Calling autowired Setter injection method");
		this.customerRepository = customerRepository;
	}

	//Before using setter level autowiring comment at memeber level autowiring annotation
	@Autowired
	public CustomerServiceImpl(CustomerRepository customerRepository) {
		System.out.println("Calling autowired constructor injection method");
		this.customerRepository = customerRepository;
	}
	
	@Override
	public List<Customer> findAll() {
		return customerRepository.findAll();
	}
	

	
}

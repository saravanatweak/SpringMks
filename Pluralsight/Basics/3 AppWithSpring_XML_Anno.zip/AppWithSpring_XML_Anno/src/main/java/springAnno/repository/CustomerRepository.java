package springAnno.repository;

import java.util.List;

import springAnno.model.Customer;

public interface CustomerRepository {

	List<Customer> findAll();

}
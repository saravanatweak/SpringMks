import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import springAnno.service.CustomerService;
import springAnno.service.CustomerServiceImpl;

public class App {

	public static void main(String[] args) {
		
		/*FLOW:
		 * And now all of our tiers, all of our pieces are all wired together. We have our application that creates an instance of our customer service object. 
		 * Our customer service object then calls our repository. The repository has a findAll method inside of there that will go ahead and create an instance of that object and return it for us. */
		
		ApplicationContext appContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		//ApplicationContext and then this will look on our Class path for us and find our applicationContext.xml file. And since we are using Maven it will automatically put that file in the right place.
		//Maven will compile that into our application at the root of our application. So in our Classes directory applicationContext.xml will be copied at the root of that directory structure so we don't have to put any path information
		
		//Step2: inside of our appContext we want to go ahead and get a reference to the customer service bean that we created.
		//To do this, we're going to create an instance of the customer service object and then use that appContext to find this bean
		CustomerService setterInjectionCustomerService = appContext.getBean("customerServiceUsingAnno", CustomerService.class);
		//Notice: this is where again we are using the interface instead of the concrete Class so that we can swap out those implementations behind the scene without having to re-compile our application
		System.out.println(setterInjectionCustomerService.findAll().get(0).getFirstname());


	}
	
}

import service.CustomerService;
import service.CustomerServiceImpl;

public class App {

	public static void main(String[] args) {
		
		/*FLOW:
		 * And now all of our tiers, all of our pieces are all wired together. We have our application that creates an instance of our customer service object. 
		 * Our customer service object then calls our repository. The repository has a findAll method inside of there that will go ahead and create an instance of that object and return it for us. */
		
		CustomerService cs = new CustomerServiceImpl();
		/*The CustomerService shouldn't know that it is using hibernate specifically. We've already abstracted that out to an interface, and this is a good example of where we could use a design pattern like a factory pattern to abstract that out of this code, but Spring makes this even easier for us.*/
		
		//So wherever you see us creating an interface and it's tied to a concrete implementation, we should try and abstract that out of our code so that our application isn't hardcoded anymore
		
		
		System.out.println(cs.findAll().get(0).getFirstname());

	}
	
	/*PAINT POINTS in normal app
	 * 
	 * */

}

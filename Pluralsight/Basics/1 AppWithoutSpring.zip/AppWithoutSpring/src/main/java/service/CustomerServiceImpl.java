package service;

import java.util.List;

import model.Customer;
import repository.CustomerRepository;
import repository.HibernateCustomerRepositoryImpl;

//service All the time business logic will be here only
public class CustomerServiceImpl implements CustomerService {

//hardcoded referecen to repository // By using spring we can eliminate this kind of configuration
private CustomerRepository customerRepository = new HibernateCustomerRepositoryImpl();
	

	@Override
	public List<Customer> findAll() {
		return customerRepository.findAll();
	}
}

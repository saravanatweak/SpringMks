package repository;

import java.util.ArrayList;
import java.util.List;

import model.Customer;

/*Named intestinally as purpose to illustrate that one of the reasons we want Spring is to be able to swap out this underlying implementation and code to the contract */
public class HibernateCustomerRepositoryImpl implements CustomerRepository {

	/* (non-Javadoc)
	 * @see repository.CustomerRepository#findAll()
	 */
	@Override
	public List<Customer> findAll() {
		
		List<Customer> customers = new ArrayList<>();
		
		Customer customer = new Customer();
		
		customer.setFirstname("Saravanakumar ");
		customer.setLastname("kalianna");
		
		customers.add(customer);
		
		return customers;
	}
}

package javaConfig.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;

import javaConfig.repository.CustomerRepository;
import javaConfig.model.Customer;

//service All the time business logic will be here only
//@Service("customerService")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)// it will take it as singleton as scope, even though you are not providing anything
public class CustomerServiceImpl implements CustomerService {

//hard coded reference to repository // By using spring we can eliminate this kind of configuration
//private CustomerRepository customerRepository = new HibernateCustomerRepositoryImpl();
	//@Autowired
	private CustomerRepository customerRepository ;
	
	public CustomerServiceImpl() {	}

	public CustomerServiceImpl(CustomerRepository customerRepository) {
		System.out.println("we are using java based constructor injection");
		this.customerRepository = customerRepository;
	}

	//@Autowired
	public void setCustomerRepository(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
		System.out.println("we are using java based Setter injection");
	}


	@Override
	public List<Customer> findAll() {
		return customerRepository.findAll();
	}
}



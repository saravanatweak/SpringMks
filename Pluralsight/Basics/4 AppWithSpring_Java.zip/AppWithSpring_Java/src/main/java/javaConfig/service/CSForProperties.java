package javaConfig.service;

import java.util.List;

import org.springframework.stereotype.Service;

import javaConfig.model.Customer;
import javaConfig.repository.CustomerRepository;

@Service("csForProperties")
public class CSForProperties implements CustomerService {

	private CustomerRepository customerRepository ;
	
	public CSForProperties() {	}
	
	public void setCustomerRepository(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
		System.out.println("we are using java based Setter injection");
	}

	
	@Override
	public List<Customer> findAll() {

		return customerRepository.findAll();
	}

}

package javaConfig.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import javaConfig.model.Customer;

//todo: try to rectify the error
@Repository("crForProperties")
public class HibernateCRForPropertiesImpl implements CustomerRepository {

	@Value("${dbUserName}")
	private String dbUserName;
	
	@Value("${dbUserPwd}")
	private String dbUserPwd;
	@Override
	public List<Customer> findAll() {
		
		System.out.println(dbUserName);
		System.out.println(dbUserPwd);
		return new ArrayList<>();
	}
	
	
	/*The reason I chose this example is because this is a case where I may want to inject in a username, possibly a password, or some other configuration information into a database tier to pull something specific back. If you've ever used some of the various database implementations out there like Oracle, for example, I can tell it which user I want to run a query under. Not necessarily what user I want to connect to the database as but, literally, what user I should implement a query under. And so, it's for a logging purposes, or configuration, there's a lot of reasons why you might want to do this, but that's one of the reasons we might want to inject that value in at runtime. */
	

}

package javaConfig.service;

import java.util.List;

import javaConfig.model.Customer;

public interface CustomerService {

	List<Customer> findAll();

}
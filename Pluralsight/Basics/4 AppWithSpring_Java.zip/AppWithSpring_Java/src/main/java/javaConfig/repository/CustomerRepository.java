package javaConfig.repository;

import java.util.List;

import javaConfig.model.Customer;

public interface CustomerRepository {

	List<Customer> findAll();

}
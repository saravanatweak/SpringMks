import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import javaConfig.service.CSForProperties;
import javaConfig.service.CustomerService;
import javaConfig.service.CustomerServiceImpl;



public class App {

	public static void main(String[] args) {
		
		ApplicationContext appContext = new AnnotationConfigApplicationContext(AppConfig.class);
		
		CustomerService service = appContext.getBean("customerService", CustomerService.class);
		//So wherever you see us creating an interface and it's tied to a concrete implementation, we should try and abstract that out of our code so that our application isn't hardcoded anymore
				
		System.out.println(service.findAll().get(0).getFirstname());
		
		//For bean scope perspective
		CustomerService service2 = appContext.getBean("customerService", CustomerService.class);
		//By singleton both service and service1 have same object. even though we've created two service instances, or gotten two service instances back from that container. That is, in effect, a singleton. It's giving us the same object back.
		System.out.println(service);
		System.out.println(service);
		
		//For Properties persfective
		CSForProperties propertiesService = appContext.getBean("csForProperties", CSForProperties.class);
		System.out.println(propertiesService.findAll());
		

	}
	
/*you can tell by looking at this Java code, that's a lot closer to what we would do without using Spring and that's one of the powerful features of using the Java Configuration is I don't have it looking like I'm doing some stuff in XML and some stuff in Java. This looks very similar to how I would go about doing it without using Spring at all for getting that new instance passed in there. */
}

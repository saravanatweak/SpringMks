import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration//. This will tell Spring as we run this code to go ahead and look for any configuration information from this file.
@ComponentScan({"javaConfigForProperties"})//Right now, this is configured to run and it'll go through and look in any code underneath javaConfig for things that it wants to autowire up
@PropertySource("app.properties")
public class AppWithProperties {

	@Bean
	public static PropertySourcesPlaceholderConfigurer getPropertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
		//So what this class does? ,
		//is takes all those properties that were loaded in from the property's source location, and puts them in this class and makes them available in the context for our application to use. So this is what was behind the scenes of that XML snippet.
	}
}

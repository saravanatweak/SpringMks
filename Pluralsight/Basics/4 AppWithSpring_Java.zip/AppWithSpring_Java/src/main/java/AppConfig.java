import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import javaConfig.repository.CustomerRepository;
import javaConfig.repository.HibernateCustomerRepositoryImpl;
import javaConfig.service.CustomerService;
import javaConfig.service.CustomerServiceImpl;

@Configuration//. This will tell Spring as we run this code to go ahead and look for any configuration information from this file.
@ComponentScan({"javaConfig"}) //Right now, this is configured to run and it'll go through and look in any code underneath javaConfig for things that it wants to autowire up
public class AppConfig {
	
/*	how is this any different than just calling the setter and the getter on our own not using Spring?
	 *Ans:As we mark that as a bean, Spring will now look in its repository and its context to see if there's any other beans already created with that name or of that instance and inject those in here. It may not actually create a new instance of that bean every time. We get that power of Spring by just having that annotation here. Even though we call it the same way in our code, behind the scenes, it's looking to see if it is a Spring bean and it's already been injected somewhere else 
*/	
	@Bean(name="customerService")
	public CustomerService getCustomerService() {
		
		CustomerServiceImpl serviceImpl = new CustomerServiceImpl();
		serviceImpl.setCustomerRepository(getCustomerRepository());
		
		//comment the above 2 lines and try to execute this construcotr based injection using java config
		//CustomerServiceImpl serviceImpl = new CustomerServiceImpl(getCustomerRepository());
		

		//once you have added @Autwired in the customerRepository variable instance on CustomerServiceImpl class 
		//comment ServiceInmpl line and run it. will work,Bcoz it will be autowired automatically when you call the default constructor of CustomerService class using @Autowire annoatation
		
		//If you added @Autowire at setter level in CustoerService class instead of customerRepository variable instance, then you if u run it'll work
		//will print as used setter injection java config. So autowire is very powerful interms of configuring or injecting beans automatically to the application.
		
		return serviceImpl;
	}
	
	//So by registering as a bean, every time we call that getCustomerRepository instance, it only gets ran the first time and returns that cached instance for us from every time after that
	@Bean(name="customerRepository")
	public CustomerRepository getCustomerRepository() {
		return new HibernateCustomerRepositoryImpl(); //This is where we are implementing an instance of the concrete class but returning the interface.
	}
	
	
	//comment the above entire getMethod and mark HibernateCustomerRepositoryImpl as @Repository stereotype annotation and run the app
	//will work automatically by the help of autowire annotation. you can try with setter/constructor level . both will work 
	//Because of component scan(hibernate is defined as @Repository as bean under this package) it will automatically wire up repository bean injectws into the app
	
	
	/*True power of Autowiring*/
	//comment out entire methods in teh appConfig and mark @Service("customerService") stereotype annotation to the CustmoerService. 
	//Run it, will work, so it will autowiring the entire application by means of componentscan
	
}




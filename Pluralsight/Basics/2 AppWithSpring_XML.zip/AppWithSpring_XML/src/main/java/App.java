import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import service.CustomerService;
import service.CustomerServiceImpl;

public class App {

	public static void main(String[] args) {
		
		/*FLOW:
		 * And now all of our tiers, all of our pieces are all wired together. We have our application that creates an instance of our customer service object. 
		 * Our customer service object then calls our repository. The repository has a findAll method inside of there that will go ahead and create an instance of that object and return it for us. */
		
		//CustomerService cs = new CustomerServiceImpl();
		//steps 
		//step1: we need to import our applicationContext.xm
		ApplicationContext appContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		//ApplicationContext and then this will look on our Class path for us and find our applicationContext.xml file. And since we are using Maven it will automatically put that file in the right place.
		//Maven will compile that into our application at the root of our application. So in our Classes directory applicationContext.xml will be copied at the root of that directory structure so we don't have to put any path information
		
		//Step2: inside of our appContext we want to go ahead and get a reference to the customer service bean that we created.
		//To do this, we're going to create an instance of the customer service object and then use that appContext to find this bean
		CustomerService setterInjectionCustomerService = appContext.getBean("customerServiceUsingSetter", CustomerService.class);
		//Notice: this is where again we are using the interface instead of the concrete Class so that we can swap out those implementations behind the scene without having to re-compile our application
/*1*/	System.out.println(setterInjectionCustomerService.findAll().get(0).getFirstname());

		//From the console
		//Our Class path, XML applicationContext has been loaded and it's gone ahead and found the bean that we've had and started up our application to where we're now able to run this application and have it pull those resources out of those bean definitions. 
	
	
		//Using constructor injection:
		CustomerService constructorInjectionCustomerService = appContext.getBean("customerServiceUsingConstructor", CustomerService.class);
/*2*/	System.out.println(constructorInjectionCustomerService.findAll().get(0).getFirstname());
		
		//Using autowire by construcotr
		CustomerService csAutowireByConstructor = appContext.getBean("csUsingAutoWire", CustomerService.class);
/*3*/	System.out.println(csAutowireByConstructor.findAll().get(0).getFirstname());
		
		//For bean scope perspective
		CustomerService setterInjectionCustomerService2 = appContext.getBean("customerServiceUsingSetter", CustomerService.class);
		//By singleton both service and service1 have same object. even though we've created two service instances, or gotten two service instances back from that container. That is, in effect, a singleton. It's giving us the same object back.
		System.out.println(setterInjectionCustomerService);
		System.out.println(setterInjectionCustomerService2);
				
		
	}
	
	
}

package service;

import java.util.List;


import model.Customer;
import repository.CustomerRepository;


//All the time business logic will be here only
public class CustomerServiceImpl implements CustomerService {

	// hardcoded reference to repository // By using spring we can eliminate this kind of configuration
	// private CustomerRepository customerRepository = new HibernateCustomerRepositoryImpl();
	private CustomerRepository customerRepository;
	
	
	//Using Constructor injection //only change in appContext.xml is instead of using property you can use constructor arg
	
	public  CustomerServiceImpl() { // default should be avaialable if parameterized is prese
	}

	public CustomerServiceImpl(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}
	
	
	@Override
	public List<Customer> findAll() {
		return customerRepository.findAll();
	}

	//Setter injection //once setter method added we have enabled to add setter property in appContext.xml file 
	public void setCustomerRepository(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}
}

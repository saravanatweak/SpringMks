package repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;

import model.Customer;

/*Named intestinally as purpose to illustrate that one of the reasons we want Spring is to be able to swap out this underlying implementation and code to the contract */
public class HibernateCustomerRepositoryImpl implements CustomerRepository {

	//Example of injecting property value through seter injection 
	private String dbUserName;
	public void setDbUserName(String dbUserName) {
		this.dbUserName = dbUserName;
	}
	
	//Example of injecting property value through annotation based. In order to utilize this feature you should add <context:annotation-config /> in your app.xml. ITs been detailed in XML_Anno pgt.  
	@Value("${dbUserUpwd}")
	private String dbUserUpwd;
	@Override
	public List<Customer> findAll() {
		//below line is just to show the property value injection from app.properties
		System.out.println(dbUserName);
		System.out.println(dbUserUpwd);
		List<Customer> customers = new ArrayList<>();
		
		Customer customer = new Customer();
		
		customer.setFirstname("Saravanakumar ");
		customer.setLastname("kalianna");
		
		
		customers.add(customer);
		
		return customers;
	}
}

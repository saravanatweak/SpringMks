import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import junit.framework.TestCase;

public class PasswordHash extends TestCase {
	private static final String password ="upwd";
	public void testMD5Hash() {
		Md5PasswordEncoder pwdEncoded = new Md5PasswordEncoder();
		String hasshedPwd = pwdEncoded.encodePassword(password, null);
		System.out.println(hasshedPwd);
	}
	
	public void testBcryptHash() {
		
		BCryptPasswordEncoder bPasswordEncoder = new BCryptPasswordEncoder();
		String bHashedPwd = bPasswordEncoder.encode(password);
		System.out.println(bHashedPwd);
	}
	
	
	
}

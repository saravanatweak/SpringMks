package com.boot.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.boot.model.Shipwreck;
import com.boot.repository.ShipwreckRepository;

@RestController
@RequestMapping("api/v1/")//The value of api/v1 specifies the base URL that all endpoints will contain for this class This class level RequestMapping annotation is setting that piece of the endpoint up for us
public class ShipwreckController {

	
	/*As part of JPA implementaion we're replacing stub db to acutal db(here we are using h2 db*/
	@Autowired
	private ShipwreckRepository shipReckJpa;
	
	
	/* The RequestMapping says that it will accept a GET request to the api/v1 shipwrecks endpoint.The method level RequestMapping annotation appends its value on to the class level annotation. */
	@RequestMapping(value="shipwrecks", method= RequestMethod.GET)
	public List<Shipwreck> list() {
		//return new ShipwreckStub().list();
		return shipReckJpa.findAll();
	}
	
	@RequestMapping(value="shipwrecks", method = RequestMethod.POST)
	public Shipwreck create(@RequestBody Shipwreck shipwreck) {
		//return ShipwreckStub.create(shipwreck);
		return shipReckJpa.saveAndFlush(shipwreck);
		
	}
	
	@RequestMapping(value="shipwrecks/{id}", method = RequestMethod.GET)
	public Shipwreck get(@PathVariable Long id) {
		//return ShipwreckStub.get(id);
		return shipReckJpa.findOne(id);
	}
	
	@RequestMapping(value="shipwrecks/{id}", method = RequestMethod.PUT)
	public Shipwreck update(@PathVariable Long id, 
			@RequestBody Shipwreck shipwreck) {
		//return ShipwreckStub.update(id, shipwreck);
		Shipwreck existingShipwreck = shipReckJpa.findOne(id);
		BeanUtils.copyProperties(shipwreck, existingShipwreck);
		return shipReckJpa.saveAndFlush(existingShipwreck);
	}
	
	@RequestMapping(value="shipwrecks/{id}", method = RequestMethod.DELETE)
	public Shipwreck delete (@PathVariable Long id) {
		return ShipwreckStub.delete(id);
	}
	
	/*All of these methods and code in this controller are all pure Spring MVC code. There's really nothing fancy that Spring Boot is doing here. The part that Spring Boot is doing for us, you can't actually see in the code. */
	/*Spring Boot is handling the integration of Spring MVC, and then it sets up the Jackson JSON library internally, so that when we send the model info across the HTTP connection, Spring Boot and Spring MVC are automatically marshalling the JSON info into and out of the class from the object. */
}

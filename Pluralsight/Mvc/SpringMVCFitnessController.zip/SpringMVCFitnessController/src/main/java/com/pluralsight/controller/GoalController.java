package com.pluralsight.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.pluralsight.model.Goal;

@Controller
@SessionAttributes("goal")//this goal ties exactly model.addAttribute("goal"..). so these 2 goals is saying, hey, when I put this in my model, I want it to be stored with a scope of session. 
public class GoalController {

	/*this method is just going to handle http requests of GET. So if I try to post to it, it's actually going to error out. \
	 * And the reason we want to do that is as we're setting up our page, we only want certain things to go to this method. */
	@RequestMapping(value="addGoal", method = RequestMethod.GET)
	public String addGoal(Model model) {
		
		/*Model in addGoad method: spring will pass in the backing model to your method and since it's passed by reference instead of passed by value, 
		 * this is a pointer back to our actual object. So it's not just going to go away at the end of this method because 
		 * it's going to be absorbed back into the framework as part of the interceptor as part of the requestLifecycle. 
		 * So this object is available for us to use and it will actually return data back to our jsp page for us*/
	
		//model.addAttribute("goal", new Goal()); //instead of passing empty value we are making some default value by below
		
		Goal goal = new Goal();
		goal.setMinutes(10);
		
		model.addAttribute("goal", goal);
		
		return "addGoal";
	}
	
	//With only above method when you try to put something you will get "Request method 'POST' not supported" error hence adding post method to get hte value and this value get stored by the help of SessionAttribute
	
	/*Flow: the first time we request it, it comes into our goalController and it returns us to addGoal with default value(as we declared) 
	 * which goes back and displays addGoal.jsp page, binds us to current object(goa), we submit back up to that so we actually 
	 * do a post back up to our controller and it will bind us to the goal object that we created. 
	 * Once it's bound and it's updated everything, it redirects us back to addMinutes.html. 
	 * There's our addMinutes.jsp page and we're ready to start adding in our minutes for the day. 
	 * And so now you can see that we've got our goalMinutes and it's pulling that out of our session.  */
	
	@RequestMapping(value = "addGoal", method = RequestMethod.POST)
	public String updateGoal(@Valid @ModelAttribute("goal") Goal goal, BindingResult result) {
		//Above line adding validations:
		/*Now, object result will actually contain the response from validation off of @valid here. 
		 * So when this method gets called and it goes to see if its valid, this object will contain whether or not it is valid and has any errors. */
		System.out.println("Result has any errors : "+ result.hasErrors());
		
		if(result.hasErrors())
			return "addGoal";
		
		System.out.println("Minutes updated: " + goal.getMinutes());
		
		return "redirect:addMinutes.html";
		//Above line, instead of returning to ourself we are making use of redirecting the value to addMinutes page and from there we are reading hte value by 
	}
	
	}



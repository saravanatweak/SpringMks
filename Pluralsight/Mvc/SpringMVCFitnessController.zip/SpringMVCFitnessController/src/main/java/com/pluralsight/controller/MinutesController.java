package com.pluralsight.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pluralsight.model.Activity;
import com.pluralsight.model.Exercise;
import com.pluralsight.service.ExerciseService;


@Controller
public class MinutesController {

	@Autowired
	private ExerciseService exerciseService;
	
	@RequestMapping(value = "/addMinutes")
	public String addMinutes(
			@ModelAttribute ("exercise") Exercise exercise) {
		
		System.out.println("exercise: " + exercise.getMinutes());

		//There are two types of chaining you can do here
//1.forward	
		//return "forward:addMoreMinutes"; if you write like this the program will break exactly here
		//and throws 404 erorr. Because it's going outside of our framework and coming back. and our app actually knows nothing to do with that because our old request was just going to add more minutes. It wasn't going to add more minutes dot HTML. So I've gone ahead and added dot HTML to that, saved it So it shuold be
		return "forward:addMoreMinutes.html";
		//Flow :So it went in one method outside of our framework and came back in and hit that method again. So by including this forward colon on the front of it, it actually bypassed our view resolver that first time and went back through as a request and then went to our view resolver on this time. 
		
//2.redirect
		//return "redirect:addMoreMinutes.html"; // you will get excercise as 0 and excerciseMore as 0. becase
		//on the redirect, it had closed our request and created a new request. So we went through once with our original request, it finished that request and came in as another request and so it had lost its exercise information. So the redirect was doing what it said it should do
		
	}
	/*Flow is : we return a string. That string is tied to our view resolver 
	 * and goes ahead and navigates as to what page that we're looking for. 
	 * So right now, it's saying that I'm looking for the addMinute string 
	 * and you can see underneath WEB-INF/jsp/addMinutes.jsp page. 
	 * Now it knows to look there based off of our internal resource reviewer 
	 * that's configured in our ServletConfig.xml. 
	 * Now people might thing we're returning a name of a JSP page out of our controller. 
	 * They think it's a little too tightly bound. But it's actually not the case. 
	 * But you can see that this string(addMinutes) really doesn't mean that it's this exact file,
	 *  but it's a key to that file. And by following that convention we can find our location.
	 *   */
	

	
	@RequestMapping(value = "/activities", method = RequestMethod.GET)
	public @ResponseBody List<Activity> findAllActivities() {//what you return is the actual content that I want to expose. So I'm saying I am returning the contents
		
		return exerciseService.findAllActivities();
	}
	
	
	@RequestMapping(value = "/addMoreMinutes")
	public String addMoreMinutes(@ModelAttribute ("exercise") Exercise exercise) {
		
		System.out.println("exerciseMore: " + exercise.getMinutes());
		
		return "addMinutes";
	}
	
	

}

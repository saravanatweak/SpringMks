package com.pluralsight.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class MinutesControllerWithoutModel {

	@RequestMapping(value = "/addMinutesWithoutModel")
	public String addMinutes() {
		return "addMinutesWithoutModel";
	}
	
	/*So to walk there what happened here, when we go to this Add Minutes.HTML, 
	 * it wants to go through our web.XML, and our web.XML says hey,
	 * send everything that is of *.HTML to our dispatcher servlet. 
	 * Well, our dispatcher servlet is configured using the servlet config. 
	 * Our servlet config says hey, I want to scan for all of my controllers 
	 * at this location(com.pluralsight.controller), I want to be annotation-driven and 
	 * I want to look for my controllers in this location here. 
	 * And since our controller is annotative to at controller, it says oh, okay, 
	 * I'm going to handle that. And since we put a request mapping on here of Add Minutes, 
	 * it says I'm the method that's going to handle that. From the server starting console page,
	 *  you can see when our server started up that we have mappings for greetings and mappings for Add Minutes to our servlet. 
	 *  So that means it picked it up, our Spring MVC configuration picked it up. 
	 *  That's one way to tell that your annotations and stuff are working right because it actually says hey, 
	 *  I've got a mapping for this file here. And then it returns our view. But in our servlet config,
	 *  there is this internal resource viewer here that says hey, look for my JSP pages in my WEB-INF directory right here and look for a suffix of .JSP.
	 *  So basically, I'm going to look for Add Minutes.JSP, this guy right here, underneath my Source, Main, Web App, WEB-INF/JSP directory. 
	 *  Now, once that's all done, it will just go ahead and return that JSP page and display our information here. */
	
}



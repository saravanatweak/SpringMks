package com.pluralsight.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {

	@RequestMapping(value ="/greeting")
	public String sayHello (Model model) {
		
		model.addAttribute("greeting", "Hello World");
		/*Model has an attribute in there with a key of greeting and a value of "Hello World." And model is just simply a hash map, basic map structure, it does a little bit more than that, but that's all you need to know for what it does for now. 
		*/
		return "hello";
	}
	
}

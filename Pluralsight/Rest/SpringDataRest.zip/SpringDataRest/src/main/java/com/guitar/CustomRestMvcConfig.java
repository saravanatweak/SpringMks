/*package com.guitar;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
*/
/*@Configuration
public class CustomRestMvcConfig extends RepositoryRestConfiguration{
	@Override
	public RepositoryRestConfiguration config () {
		RepositoryRestConfiguration config = super.config();
		config.setBasePath("/api");
		return config;
}	}*/

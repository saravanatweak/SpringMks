package com.guitar.repository;

public class ModelJpaRepositoryImpl implements ModelJpaRepositoryCustom {

	@Override
	public void aCustomMethod() {
		System.out.println("I'm a custom method");
	}

}

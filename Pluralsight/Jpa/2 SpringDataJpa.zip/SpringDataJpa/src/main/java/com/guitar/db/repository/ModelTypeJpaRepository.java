package com.guitar.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.guitar.db.model.ModelType;

public interface ModelTypeJpaRepository extends JpaRepository<ModelType, Long> {
	
	//We are testing IsNull, IsNotNull, and NotNull keywords
	
	List<ModelType> findByNameIsNull();
	
	List<ModelType> findByNameIsNotNull(long id); //NotNull more or less same
	
	
	
	



}

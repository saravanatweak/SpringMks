package com.guitar.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.guitar.db.model.Location;

public interface LocationJpaRepository extends JpaRepository<Location, Long> {

	/*Spring Data JPA checks these queries at application start-up. So to test that out, 
	 * let's go ahead and change something in our query contract method to see if that's really true. 
	 * So state is an attribute on our model and it's of type String. So all I need to do to 
	 * break this is change something other than the attribute name that's defined in the model. 
	 * like findByStates, plural, that attribute now does not exist, and in fact, 
	 * the Spring Tool Suite already recognizes that and says, 
	 * "Invalid derived query! No property states found for type Location! Did you mean 'state'?."
	 * unComment below line to see that */
	//List<Location> findByStatesLike(String stateName);
	
	
	List<Location> findByStateLike(String name); 
	
	//Checking Or and And Keywords of Spring JPA
	List<Location> findByStateOrCountry(String Val1, String val2);
	List<Location> findByStateAndCountry(String Val1, String val2);
/*For Above And query you will get an sequel from JPA as 
 * [org.hibernate.SQL] - <select location0_.id as id1_0_, location0_.country as country2_0_, 
 * location0_.state as state3_0_ from Location location0_ where location0_.state=? 
 * and[Incase of OR method its or] location0_.country=?>*/
	
	//Checking Equals is and NOt keywords Spring JPA
	List<Location> findByStateIsOrCountryEquals(String Val1, String val2); //producing equal meaning of Or keyword  
	List<Location> findByStateNot(String Val1); //Equally to OR keyword 
	
	//IgnoreCase 
	List<Location>  findByStateIgnoreCaseLike(String name);
	
	//OrderBy
	List<Location> findByStateNotLikeOrderByStateAsc(String name);
}
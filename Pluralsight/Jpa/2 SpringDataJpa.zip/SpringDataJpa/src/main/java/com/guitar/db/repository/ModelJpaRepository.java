package com.guitar.db.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.guitar.db.model.Model;


public interface ModelJpaRepository extends JpaRepository<Model, Long>, ModelJpaRepositoryCustom {

	//Testing <. <= >, >= keywords 
	List<Model> findByPriceGreaterThanEqualAndPriceLessThanEqual(BigDecimal lowVal,BigDecimal highVal);
	
	
	/*List<Model> findByModelType(List<String> types);
	 * The problem with this, though, is that the model type is not a String type, 
	 * and if we were to run this, we would get a data mismatch here because 
	 * we're trying to compare a String with a model type. But Spring Data JPA is 
	 * it knows that this is a relationship, a parent object. 
	 * So, after the model type declaration, we can begin to append an attribute off that. 
	 * So, we can look for the name on the model type where all of my list of Strings match 
	 * what I'm passing in. So, this is doing an In comparison on the parent object name attribute. */
	
	List<Model> findByModelTypeNameIn(List<String> types);
	
	
	/*Converting the below NamedQuery from entity
	 * @NamedQuery(name="Model.findAllModelsByType", 
		query="select m from Model m where m.modelType.name = :name")*/
	
	List<Model> findAllModelsByType(@Param("name") String name);
	
	
	/*Converting NamedQuery into Spring Data JPA NamedQuery
	 * @SuppressWarnings("unchecked")
	List<Model> mods = entityManager
				.createQuery("select m from Model m where m.price >= :lowest and m.price <= :highest and m.woodType like :wood")
				.setParameter("lowest", lowest)
				.setParameter("highest", highest)
				.setParameter("wood", "%" + wood + "%").getResultList();*/
	@Query("select m from Model m where m.price >= :lowest and m.price <= :highest and m.woodType like :wood")
	List<Model> queryByPriceRangeAndWoodType(@Param("lowest") BigDecimal lowest,
											 @Param("highest") BigDecimal highest,
											 @Param("wood") String wood);
	
	
	//Testing Pagination in @query 
	@Query("select m from Model m where m.price >= :lowest and m.price <= :highest and m.woodType like :wood")
	Page<Model> queryByPriceRangeAndWoodTypeInPagination(@Param("lowest") BigDecimal lowest,
											 @Param("highest") BigDecimal highest,
											 @Param("wood") String wood,
											 Pageable page);
}

package com.guitar.db.repository;

public interface ModelJpaRepositoryCustom {

	/* We can call the custom interface anything we want, but that class name has to match the 
	 * JPA repository we're trying to tie with. So, we need to start this with model JPA repository. 
	 * And the default suffix that Spring will look for is I-M-P-L, or IMPL. 
	 * If we were to choose another suffix, we would have to set up the configuration to find it 
	 * or else Spring Data JPA is not going to know about this class and we'll still get errors 
	 * when we run the application. This class should also extend your custom interface that we just added. 
	 * The other thing to know here is that this going to be Spring enabled. 
	 * We mean that we can inject information or auto wire information into here. 
	 * So if we wanted to inject the entity manager or the do something like that, 
	 * maybe the Spring JDBC template, we can add that information in here and 
	 * then utilize it in our custom methods. */
	void aCustomMethod();
}

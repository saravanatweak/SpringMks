package com.guitar.db.repository;


import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.guitar.db.model.Manufacturer;

/*;
 * leaving existing JPA repository in place and turn it 
 * into a proxy to the new Spring JPA repository you're replacing it with */  

public interface ManufactureJpaRepository extends JpaRepository<Manufacturer, Long> {
	
	List<Manufacturer> findByFoundedDateBefore(Date date);
	
	 /*select manufactur0_.id as id1_1_, manufactur0_.averageYearlySales as averageY2_1_, manufactur0_.foundedDate as foundedD3_1_, manufactur0_.headquarters_id as headquar5_1_, manufactur0_.name as name4_1_ from Manufacturer manufactur0_ where manufactur0_.foundedDate<?*/

	//Adding True or False queries
	List<Manufacturer> findByActiveTrue();
	List<Manufacturer> findByActiveFalse();
	
	/*Replacing NamedNativeQuery from the Manufacture Entity to Spring Jpa format
	 * @NamedNativeQuery(name = "Manufacturer.getAllThatSellAcoustics", 
		query = "SELECT m.id, m.name, m.foundedDate, m.averageYearlySales, m.location_id as headquarters_id, m.active "
	    + "FROM Manufacturer m "
		+ "LEFT JOIN Model mod ON (m.id = mod.manufacturer_id) "
		+ "LEFT JOIN ModelType mt ON (mt.id = mod.modeltype_id) "
	    + "WHERE (mt.name = ?)", resultClass = Manufacturer.class)*/
	
	List<Manufacturer> getAllThatSellAcoustics(String name);
}

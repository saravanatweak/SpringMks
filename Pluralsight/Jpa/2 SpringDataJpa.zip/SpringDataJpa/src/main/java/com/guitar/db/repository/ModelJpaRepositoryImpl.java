package com.guitar.db.repository;

public class ModelJpaRepositoryImpl implements ModelJpaRepositoryCustom  {

	@Override
	public void aCustomMethod() {
		System.out.println("We are in the Custome JPA implemented class");
		
	}

	
}

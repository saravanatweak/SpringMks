package com.guitar.db.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.guitar.db.model.Manufacturer;

/*
 * leaving existing JPA repository in place and turn it 
 * into a proxy to the new Spring JPA repository you're replacing it with */
  

@Repository
public class ManufacturerRepository {
	@PersistenceContext
	private EntityManager entityManager;


	//Injecting Spring Data JPA Repository and making the old repository as proxy to Spring JPA.
	@Autowired
	private ManufactureJpaRepository manufactureJpaRepository;
	
	
	public Manufacturer create(Manufacturer man) {
		/*entityManager.persist(man);
		entityManager.flush();
		return man;*/
		return manufactureJpaRepository.saveAndFlush(man);
	}

	/*In Spring Data JPA both create and update are combined into SavenAndFlush. 
	 Spring internally differentiate which one is create or update*/
	public Manufacturer update(Manufacturer man) {
		/*man = entityManager.merge(man);
		entityManager.flush();
		return man;*/
		return manufactureJpaRepository.saveAndFlush(man);
	}

	
	public void delete(Manufacturer man) {
		/*entityManager.remove(man);
		entityManager.flush();*/
		manufactureJpaRepository.delete(man);
	}

	public Manufacturer find(Long id) {
//		return entityManager.find(Manufacturer.class, id);
		return manufactureJpaRepository.findOne(id);
	}

	/*Get Replaced by Spring JPA*/
	public List<Manufacturer> getManufacturersFoundedBeforeDate(Date date) {
		/*@SuppressWarnings("unchecked")
		List<Manufacturer> mans = entityManager
				.createQuery("select m from Manufacturer m where m.foundedDate < :date")
				.setParameter("date", date).getResultList();
		return mans;*/
		return manufactureJpaRepository.findByFoundedDateBefore(date);
	}

	/**
	 * Custom finder
	 */
	public Manufacturer getManufacturerByName(String name) {
		Manufacturer man = (Manufacturer)entityManager
				.createQuery("select m from Manufacturer m where m.name like :name")
				.setParameter("name", name + "%").getSingleResult();
		return man;
	}

	/**
	 * Named Native Query finder
	 */
	public List<Manufacturer> getManufacturersThatSellModelsOfType(String modelType) {
		/*@SuppressWarnings("unchecked")
		List<Manufacturer> mans = entityManager
				.createNamedQuery("Manufacturer.getAllThatSellAcoustics")
				.setParameter(1, modelType).getResultList();
		return mans;*/
		// Replaced by Spring JPA 
		return manufactureJpaRepository.getAllThatSellAcoustics(modelType);
	}
}
